
		<?php
		return array(
"atendimento" => "Atendimento", "financeiro" => "Financeiro", "alta" => "Alta", "aberto" => "Aberto", "0" => "0", 
);