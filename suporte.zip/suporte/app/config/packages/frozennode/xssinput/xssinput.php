<?php

return array(

	/**
	 * Whether to globally filter all inputs
	 *
	 * @type bool
	 */
	'xss_filter_all_inputs' => true,

);