<div class="modal fade" id="solsoCrudModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog modal-lg">
	<div class="modal-content">
		<div class="modal-header">
			<h4 class="solsoModalTitle"></h4>
		</div>
		
		<div class="modal-body">
			<div class="row solsoShowForm"></div>
		</div>
		
		<div class="modal-footer">
			<button type="reset" class="btn btn-default" data-dismiss="modal">
				{{ trans('translate.cancel') }}
			</button>
		</div>
	</div>
</div>
</div>

