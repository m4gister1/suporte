@include('begin')

<div class="container-fluid">
<div class="row">
	@yield('content')
</div>
</div>

@include('end')