<?php

class TicketPriority extends Eloquent {

	public $timestamps = false;
}