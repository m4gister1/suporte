<?php

class Invitation extends Eloquent {

	public $timestamps = false;
	
}