<?php

class Department extends Eloquent {

	public $timestamps = false;
	
}