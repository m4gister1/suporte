<?php

class InvitationSetting extends Eloquent {

	public $timestamps = false;
	
}