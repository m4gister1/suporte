<?php

class TicketStatus extends Eloquent {

	public $timestamps = false;
}