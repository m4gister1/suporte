<?php

class TicketType extends Eloquent {

	public $timestamps = false;
}